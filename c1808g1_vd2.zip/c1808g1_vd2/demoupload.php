<?php
 //upload file 
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST["btnUpload"])) {
        $path = "uploads/";
        $fileName = time() . $_FILES['fu']['name'];//luu filename vao database
        move_uploaded_file($_FILES['fu']['tmp_name'], $path . $fileName);
        header("location:{$_SERVER['PHP_SELF']}");
    }
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>

<body>
    <form action="" method="post" enctype="multipart/form-data">
        <div><input type="file" name="fu" id="fu"></div>
        <div><input type="submit" name="btnUpload" value="upload"></div>
    </form>
</body>

</html> 