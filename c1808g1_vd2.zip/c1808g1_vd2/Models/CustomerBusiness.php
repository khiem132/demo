<?php
include_once("KhachHang.php");
class DBContext
{
   public function GetConnection()
    {
        $db = "qlvt";
        $Host = "localhost";
        $uid = "sangcp";
        $pwd = "123456";
        $link = mysqli_connect($Host, $uid, $pwd, $db);
        if (!$link) {
            echo "Error: Unable to connect to MySQL." . PHP_EOL;        
        }
        return $link;
    }
   public function GetAllCustomer()
    {
        $conn = self::GetConnection();
        mysqli_set_charset($conn, "utf8");
        $strquery = "SELECT * FROM khachhang";
        $res = $conn->query($strquery);       
        $arrKH=array();
        while ($row = $res->fetch_assoc()) {
            //printf ("%s (%s)\n", $row["Name"], $row["CountryCode"]);
            $itemKH=new KhachHang();
            $itemKH->setID($row["id"]);    
            $itemKH->setTenKh($row["tenkh"]);    
            $arrKH[]=$itemKH;
        }
    
        /* free result set */
        $res->free();
        return $arrKH;
    }
}
                        