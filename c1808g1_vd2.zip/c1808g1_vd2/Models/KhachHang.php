<?php
//class definition Customer

class KhachHang{
    //encapsulation
    private $id;
    private $tenKh;
    //interaction
    public function getID(){
        return $this->id;
    }
    public function setID($prmID){
        $this->id=$prmID;
    }
    public function getTenKh(){
        return $this->tenKh;
    }
    public function setTenKh($prmTenkh){
        $this->tenKh=$prmTenkh;
    }
}
//$k=new KhachHang();
//$k->getID();
?>